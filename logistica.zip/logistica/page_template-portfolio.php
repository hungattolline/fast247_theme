<?php
/*
Template Name: Portfolio
*/


	get_template_part('layout', 'portfolio');
