<?php

	get_template_part('layout', 'singular');
